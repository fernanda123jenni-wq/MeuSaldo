package com.meusaldo.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
