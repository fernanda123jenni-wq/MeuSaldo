import 'package:flutter_test/flutter_test.dart';
import 'package:meu_saldo/main.dart';

void main() {
  testWidgets('MeuSaldo abre a tela inicial', (WidgetTester tester) async {
    await tester.pumpWidget(const MeuSaldoApp());
    expect(find.text('MeuSaldo'), findsOneWidget);
    expect(find.text('Saldo disponível'), findsOneWidget);
  });
}
